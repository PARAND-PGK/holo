from app.services.users import validate_password

def test_password_policy():
    assert validate_password('Abc12345!')
    assert not validate_password('abc12345')
