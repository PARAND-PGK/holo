def test_coin_conversion_is_integer():
    toman=25000
    assert toman % 100 == 0
    assert toman//100 == 250
