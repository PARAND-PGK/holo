"""PODE local launcher. Run with: python main.py"""
from app.main import run
import asyncio

if __name__ == '__main__':
    asyncio.run(run())
