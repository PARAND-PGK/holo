#!/bin/sh
set -eu
mkdir -p backups
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
pg_dump "$DATABASE_URL" --format=custom --file="backups/pode_${STAMP}.dump"
find backups -type f -name 'pode_*.dump' -mtime +14 -delete
