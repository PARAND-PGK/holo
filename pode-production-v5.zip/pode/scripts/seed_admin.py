import asyncio, os
from sqlalchemy import select
from app.db.session import SessionLocal
from app.models.entities import Admin
async def main():
    ids=[int(x) for x in os.getenv('ADMIN_IDS','').split(',') if x.strip().isdigit()]
    async with SessionLocal() as s:
        for tg in ids:
            row=await s.scalar(select(Admin).where(Admin.telegram_user_id==tg))
            if not row:s.add(Admin(telegram_user_id=tg,role='SUPER_ADMIN',active=True))
        await s.commit()
if __name__=='__main__': asyncio.run(main())
