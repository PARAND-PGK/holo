# PODE — Task + Referral + Wallet Platform

PODE یک پلتفرم واقعی Telegram Bot برای Task، Referral، Daily Reward، کیف پول، Ledger مالی و برداشت است.

## اجرای سریع بدون Docker (Windows / Local)

برای اجرای محلی PODE فقط Python لازم است؛ PostgreSQL و Redis در این حالت لازم نیستند. Database به صورت فایل `pode.db` با SQLite ساخته می‌شود و FSM از حافظه استفاده می‌کند.

1. Python 3.12+ را نصب کنید.
2. `.env.example` را به `.env` کپی کنید.
3. مقدار `MAIN_BOT_TOKEN` و `VERIFICATION_BOT_TOKEN` را وارد کنید.
4. در Terminal داخل پوشه پروژه اجرا کنید:

```bash
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python main.py
```

در اولین اجرا فایل `pode.db` خودکار ساخته می‌شود و جداول ایجاد می‌شوند. برای اجرای دوباره فقط:

```bash
.venv\Scripts\activate
python main.py
```

در این حالت **Docker، PostgreSQL و Redis لازم نیستند**. برای Production بهتر است بعداً به PostgreSQL و Redis برگردید.

## معماری
- Python 3.12+
- aiogram 3.x
- PostgreSQL 17
- SQLAlchemy 2 Async + asyncpg
- Redis 8
- FastAPI Admin API
- Alembic
- Docker Compose
- Argon2id

## اجرا با Docker
1. `.env.example` را به `.env` کپی کنید.
2. توکن دو ربات، `ADMIN_IDS` و `ADMIN_API_SECRET` را تنظیم کنید.
3. اجرا:

```bash
docker compose up -d --build
```

4. Migration:

```bash
docker compose exec app alembic upgrade head
```

5. ساخت Admin اولیه:

```bash
docker compose exec app python scripts/seed_admin.py
```

پنل داخلی: `http://SERVER:8000/admin`

### امنیت پنل
هر درخواست مدیریتی باید دو Header داشته باشد:
- `X-Admin-ID`
- `X-Admin-Secret`

API را مستقیماً روی اینترنت بدون Reverse Proxy، TLS و محدودسازی شبکه منتشر نکنید.

## ربات‌ها
- Main Bot: ثبت‌نام، Login، Task، Evidence، Referral، Daily Reward، Wallet، Withdrawal، Notifications
- Verification Bot: صدور کد ۶ رقمی یک‌بارمصرف با TTL و Rate Limit

## مالی
تمام تغییرات موجودی از Ledger عبور می‌کنند. Wallet دارای `available` و `locked` است. Lock برداشت در یک تراکنش دیتابیس انجام می‌شود و رد برداشت آن را Refund می‌کند.

مقادیر پول به صورت Integer/Decimal نگهداری می‌شوند و Floating Point استفاده نمی‌شود.

## Anti-duplicate
- Telegram ID و Phone یکتا
- Referral یک‌بار برای هر referred user
- Daily Reward با Unique(User, Date)
- Submissionهای Pending و Approved با Partial Unique Index
- Wallet Transaction با Idempotency Key
- Withdrawal ID یکتا
- Approval/Payment با Row Lock

## Backup
قبل از backup، `DATABASE_URL` را تنظیم کنید:

```bash
./scripts/backup.sh
```

فایل‌های backup به صورت custom dump ذخیره می‌شوند و dumpهای قدیمی‌تر از ۱۴ روز پاک می‌شوند.

## تست
```bash
pytest -q
```

## متغیرهای محیطی
همه Secretها فقط در `.env` قرار می‌گیرند. `.env` نباید Commit شود. `.env.example` فقط نمونه است.

## نکته Production
قبل از استفاده با پول واقعی، حتماً PostgreSQL backup/restore را روی یک محیط جداگانه آزمایش کنید، TLS و reverse proxy برای Admin API قرار دهید، Secretها را rotate کنید و تست‌های load/concurrency را در محیط staging اجرا کنید.


## V5 Local Admin Panel

1. Copy `.env.example` to `.env`.
2. Set `MAIN_BOT_TOKEN`, `VERIFICATION_BOT_TOKEN`, your Telegram numeric ID in `ADMIN_IDS`, and a private `ADMIN_API_SECRET`.
3. Install dependencies: `pip install -r requirements.txt`.
4. Run: `python main.py`.
5. Open: `http://127.0.0.1:8000/admin`
6. Enter the same Telegram ID and `ADMIN_API_SECRET`.

V5 automatically creates the listed admin as `SUPER_ADMIN` in the local database. The web panel, main bot, and verification bot run together from one command.
