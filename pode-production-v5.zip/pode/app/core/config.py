from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file='.env', extra='ignore', case_sensitive=False)
    environment: str = 'development'
    main_bot_token: str = Field(default='')
    verification_bot_token: str = Field(default='')
    database_url: str = 'sqlite+aiosqlite:///./pode.db'
    redis_url: str = 'redis://localhost:6379/0'
    secret_key: str = 'local-dev-secret-change-me'
    password_pepper: str = 'local-dev-pepper-change-me'
    admin_ids: str = ''
    admin_api_secret: str = ''
    admin_host: str = '127.0.0.1'
    admin_port: int = 8000
    verification_bot_username: str = 'PODE_VerificationBot'
    main_bot_username: str = 'PODE_BOT'
    timezone: str = 'Asia/Tehran'
    def admin_id_set(self) -> set[int]:
        return {int(x.strip()) for x in self.admin_ids.split(',') if x.strip().isdigit()}
settings = Settings()
