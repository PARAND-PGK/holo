from aiogram.fsm.state import State, StatesGroup
class Registration(StatesGroup): name=State(); phone=State(); verification=State(); password=State(); password_confirm=State()
class Login(StatesGroup): phone=State(); verification=State(); password=State()
class TaskFlow(StatesGroup): evidence=State()
class WithdrawalFlow(StatesGroup): amount=State(); card=State(); holder=State(); confirm=State()
