from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.entities import User, Referral, ReferralStatus, ReferralReward, TaskSubmission, SubmissionStatus, TransactionType
from app.services.wallet import credit
from app.models.entities import utcnow

async def attribute(s: AsyncSession, referred_user_id: int, code: str):
    if not code: return None
    referred = await s.get(User, referred_user_id)
    referrer = await s.scalar(select(User).where(User.referral_code == code))
    if not referred or not referrer or referrer.id == referred.id: return None
    existing = await s.scalar(select(Referral).where(Referral.referred_user_id == referred.id))
    if existing: return existing
    row=Referral(referrer_user_id=referrer.id,referred_user_id=referred.id,code=code,status=ReferralStatus.ATTRIBUTED)
    s.add(row); await s.flush(); return row

async def reward_if_qualified(s: AsyncSession, referred_user_id: int):
    ref=await s.scalar(select(Referral).where(Referral.referred_user_id==referred_user_id).with_for_update())
    if not ref or ref.status in (ReferralStatus.REWARDED, ReferralStatus.FRAUD): return False
    approved=await s.scalar(select(TaskSubmission).where(TaskSubmission.user_id==referred_user_id,TaskSubmission.status==SubmissionStatus.APPROVED).limit(1))
    if not approved: return False
    ref.status=ReferralStatus.QUALIFIED
    rr=await s.scalar(select(ReferralReward).where(ReferralReward.referral_id==ref.id).with_for_update())
    if rr: ref.status=ReferralStatus.REWARDED; return False
    referrer_reward=150; referred_reward=50
    await credit(s,ref.referrer_user_id,referrer_reward,TransactionType.REFERRAL_REWARD,'Referral reward',str(ref.id),f'referral-referrer:{ref.id}')
    await credit(s,ref.referred_user_id,referred_reward,TransactionType.REFERRAL_REWARD,'Referred user reward',str(ref.id),f'referral-referred:{ref.id}')
    s.add(ReferralReward(referral_id=ref.id,referrer_coins=referrer_reward,referred_coins=referred_reward))
    ref.status=ReferralStatus.REWARDED; ref.rewarded_at=utcnow(); await s.flush(); return True
