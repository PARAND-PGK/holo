from datetime import timedelta, timezone
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.entities import VerificationCode, utcnow
from app.security.codes import make_code, hash_code, verify_code


def _utc(dt):
    # SQLite does not preserve timezone info for DateTime(timezone=True).
    # Normalize both SQLite-naive and PostgreSQL-aware datetimes to UTC-aware.
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


async def issue_code(s: AsyncSession, tg_id: int, ttl: int = 120):
    # Invalidate every previous active code for this Telegram account.
    await s.execute(
        update(VerificationCode)
        .where(
            VerificationCode.telegram_user_id == tg_id,
            VerificationCode.consumed_at.is_(None),
        )
        .values(consumed_at=utcnow())
    )
    code = make_code()
    row = VerificationCode(
        telegram_user_id=tg_id,
        code_hash=hash_code(code),
        expires_at=utcnow() + timedelta(seconds=ttl),
    )
    s.add(row)
    await s.flush()
    return code


async def verify(s: AsyncSession, tg_id: int, code: str, max_attempts: int = 5):
    row = await s.scalar(
        select(VerificationCode)
        .where(
            VerificationCode.telegram_user_id == tg_id,
            VerificationCode.consumed_at.is_(None),
        )
        .order_by(VerificationCode.created_at.desc())
        .with_for_update()
    )

    if not row:
        return False

    if row.expires_at is None or _utc(row.expires_at) <= utcnow():
        return False

    if row.attempts >= max_attempts:
        return False

    row.attempts += 1

    if not verify_code(code, row.code_hash):
        return False

    # Consume immediately; the caller commits the transaction.
    row.consumed_at = utcnow()
    return True
