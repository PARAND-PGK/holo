from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.entities import Setting
DEFAULTS={'coin_value_toman':'100','minimum_withdrawal_coins':'1000','daily_reward':'100','referrer_reward':'150','referred_reward':'50','verification_code_expiry':'120','max_verification_attempts':'5','timezone':'Asia/Tehran'}
async def get_setting(s:AsyncSession,key:str,default=None):
    row=await s.get(Setting,key); return row.value if row else (DEFAULTS.get(key,default))
async def set_setting(s:AsyncSession,key:str,value:str):
    row=await s.get(Setting,key)
    if row: row.value=str(value)
    else: s.add(Setting(key=key,value=str(value)))
    await s.flush()
