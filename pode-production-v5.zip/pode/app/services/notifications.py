from sqlalchemy.ext.asyncio import AsyncSession
from app.models.entities import Notification
async def notify(s: AsyncSession,user_id:int,kind:str,text:str):
    s.add(Notification(user_id=user_id,type=kind,text=text,read=False)); await s.flush()
