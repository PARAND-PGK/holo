from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.entities import Wallet, WalletTransaction, TransactionType

async def ensure_wallet(s: AsyncSession, user_id: int):
    w = await s.scalar(select(Wallet).where(Wallet.user_id == user_id).with_for_update())
    if w is None:
        w = Wallet(user_id=user_id, available=0, locked=0)
        s.add(w); await s.flush()
    return w

async def _existing(s, key):
    return await s.scalar(select(WalletTransaction).where(WalletTransaction.idempotency_key == key))

async def credit(s, user_id, amount, tx_type, description, reference_id, idempotency_key, actor_admin_id=None):
    if amount <= 0: raise ValueError('amount must be positive')
    if await _existing(s, idempotency_key): return await _existing(s, idempotency_key)
    w = await ensure_wallet(s, user_id)
    before = w.available; w.available += int(amount); w.version += 1
    tx = WalletTransaction(user_id=user_id, amount=int(amount), balance_before=before, balance_after=w.available,
        type=tx_type, description=description, reference_id=reference_id, idempotency_key=idempotency_key, actor_admin_id=actor_admin_id)
    s.add(tx); await s.flush(); return tx

async def debit(s, user_id, amount, tx_type, description, reference_id, idempotency_key, actor_admin_id=None):
    if amount <= 0: raise ValueError('amount must be positive')
    if await _existing(s, idempotency_key): return await _existing(s, idempotency_key)
    w = await ensure_wallet(s, user_id)
    if w.available < amount: raise ValueError('insufficient funds')
    before=w.available; w.available -= int(amount); w.version += 1
    tx=WalletTransaction(user_id=user_id, amount=-int(amount), balance_before=before, balance_after=w.available,
        type=tx_type, description=description, reference_id=reference_id, idempotency_key=idempotency_key, actor_admin_id=actor_admin_id)
    s.add(tx); await s.flush(); return tx

async def lock_withdrawal(s,user_id,coins,reference_id):
    if coins <= 0: raise ValueError('invalid amount')
    key=f'withdraw-lock:{reference_id}'
    if await _existing(s,key): return await _existing(s,key)
    w=await ensure_wallet(s,user_id)
    if w.available < coins: raise ValueError('insufficient funds')
    before=w.available; w.available-=coins; w.locked+=coins; w.version+=1
    tx=WalletTransaction(user_id=user_id,amount=-coins,balance_before=before,balance_after=w.available,type=TransactionType.WITHDRAWAL_LOCK,
        reference_id=reference_id,description='Withdrawal amount locked',idempotency_key=key)
    s.add(tx); await s.flush(); return tx

async def refund_withdrawal(s,user_id,coins,reference_id):
    key=f'withdraw-refund:{reference_id}'
    if await _existing(s,key): return await _existing(s,key)
    w=await ensure_wallet(s,user_id)
    if w.locked < coins: raise ValueError('invalid locked balance')
    before=w.available; w.locked-=coins; w.available+=coins; w.version+=1
    tx=WalletTransaction(user_id=user_id,amount=coins,balance_before=before,balance_after=w.available,type=TransactionType.WITHDRAWAL_REFUND,
        reference_id=reference_id,description='Withdrawal refunded',idempotency_key=key)
    s.add(tx); await s.flush(); return tx

async def complete_withdrawal(s,user_id,coins,reference_id):
    key=f'withdraw-complete:{reference_id}'
    if await _existing(s,key): return await _existing(s,key)
    w=await ensure_wallet(s,user_id)
    if w.locked < coins: raise ValueError('invalid locked balance')
    before=w.available; w.locked-=coins; w.version+=1
    tx=WalletTransaction(user_id=user_id,amount=0,balance_before=before,balance_after=w.available,type=TransactionType.WITHDRAWAL_COMPLETED,
        reference_id=reference_id,description='Withdrawal completed',idempotency_key=key)
    s.add(tx); await s.flush(); return tx
