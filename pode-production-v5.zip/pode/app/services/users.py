import secrets,re
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.entities import User, Wallet, UserStatus
from app.security.passwords import hash_password, verify_password

def validate_password(p): return len(p)>=8 and bool(re.search(r'[A-Z]',p)) and bool(re.search(r'[a-z]',p)) and bool(re.search(r'\d',p)) and bool(re.search(r'[^A-Za-z0-9]',p))
def referral_code(): return secrets.token_hex(6).upper()
def clean_name(name):
    name=name.strip(); return 2<=len(name)<=80 and all(ord(c)>=32 and ord(c)!=127 for c in name)
async def create_user(s,tg_id,phone,name,password):
    if not validate_password(password) or not clean_name(name): raise ValueError('invalid data')
    if await s.scalar(select(User).where((User.telegram_user_id==tg_id)|(User.phone==phone))): raise ValueError('duplicate user')
    u=User(telegram_user_id=tg_id,phone=phone,name=name.strip(),password_hash=hash_password(password),referral_code=referral_code())
    s.add(u); await s.flush(); s.add(Wallet(user_id=u.id)); await s.flush(); return u
async def authenticate(s,tg_id,phone,password):
    u=await s.scalar(select(User).where(User.telegram_user_id==tg_id,User.phone==phone))
    return u if u and u.status==UserStatus.ACTIVE and verify_password(u.password_hash,password) else None
