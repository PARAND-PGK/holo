import enum, uuid
from datetime import datetime, date
from decimal import Decimal
from sqlalchemy import String, text as sa_text, BigInteger, Boolean, Integer, Text, ForeignKey, Date, DateTime, Numeric, UniqueConstraint, Index, Enum as SAEnum
from sqlalchemy.orm import Mapped, mapped_column
from app.models.base import Base, TimestampMixin, utcnow

class UserStatus(str, enum.Enum): ACTIVE='ACTIVE'; BLOCKED='BLOCKED'
class SubmissionStatus(str, enum.Enum): PENDING='PENDING'; APPROVED='APPROVED'; REJECTED='REJECTED'
class WithdrawalStatus(str, enum.Enum): PENDING='PENDING'; PAID='PAID'; REJECTED='REJECTED'; REFUNDED='REFUNDED'
class TransactionType(str, enum.Enum): TASK_REWARD='TASK_REWARD'; REFERRAL_REWARD='REFERRAL_REWARD'; DAILY_REWARD='DAILY_REWARD'; ADMIN_CREDIT='ADMIN_CREDIT'; ADMIN_DEBIT='ADMIN_DEBIT'; WITHDRAWAL_LOCK='WITHDRAWAL_LOCK'; WITHDRAWAL_REFUND='WITHDRAWAL_REFUND'; WITHDRAWAL_COMPLETED='WITHDRAWAL_COMPLETED'
class ReferralStatus(str, enum.Enum): ATTRIBUTED='ATTRIBUTED'; QUALIFIED='QUALIFIED'; REWARDED='REWARDED'; FRAUD='FRAUD'

class User(TimestampMixin, Base):
    __tablename__='users';
    id: Mapped[int]=mapped_column(primary_key=True)
    telegram_user_id: Mapped[int]=mapped_column(BigInteger, unique=True, index=True)
    phone: Mapped[str]=mapped_column(String(32), unique=True, index=True)
    name: Mapped[str]=mapped_column(String(80))
    password_hash: Mapped[str]=mapped_column(String(512))
    status: Mapped[UserStatus]=mapped_column(SAEnum(UserStatus), default=UserStatus.ACTIVE)
    referral_code: Mapped[str]=mapped_column(String(32), unique=True, index=True)

class Wallet(Base):
    __tablename__='wallets';
    user_id: Mapped[int]=mapped_column(ForeignKey('users.id', ondelete='CASCADE'), primary_key=True)
    available: Mapped[int]=mapped_column(BigInteger, default=0, nullable=False)
    locked: Mapped[int]=mapped_column(BigInteger, default=0, nullable=False)
    version: Mapped[int]=mapped_column(Integer, default=0, nullable=False)

class WalletTransaction(TimestampMixin, Base):
    __tablename__='wallet_transactions'
    id: Mapped[uuid.UUID]=mapped_column(primary_key=True, default=uuid.uuid4)
    user_id: Mapped[int]=mapped_column(ForeignKey('users.id'), index=True)
    amount: Mapped[int]=mapped_column(BigInteger)
    balance_before: Mapped[int]=mapped_column(BigInteger)
    balance_after: Mapped[int]=mapped_column(BigInteger)
    type: Mapped[TransactionType]=mapped_column(SAEnum(TransactionType), index=True)
    reference_id: Mapped[str|None]=mapped_column(String(128), nullable=True, index=True)
    description: Mapped[str]=mapped_column(String(255))
    actor_admin_id: Mapped[int|None]=mapped_column(BigInteger, nullable=True)
    idempotency_key: Mapped[str]=mapped_column(String(128), unique=True)

class VerificationCode(TimestampMixin, Base):
    __tablename__='verification_codes'
    id: Mapped[uuid.UUID]=mapped_column(primary_key=True, default=uuid.uuid4)
    telegram_user_id: Mapped[int]=mapped_column(BigInteger, index=True)
    code_hash: Mapped[str]=mapped_column(String(128))
    expires_at: Mapped[datetime]=mapped_column(DateTime(timezone=True))
    consumed_at: Mapped[datetime|None]=mapped_column(DateTime(timezone=True), nullable=True)
    attempts: Mapped[int]=mapped_column(Integer, default=0)
    __table_args__=(Index('ix_verification_active','telegram_user_id','expires_at'),)

class Session(TimestampMixin, Base):
    __tablename__='sessions'
    id: Mapped[uuid.UUID]=mapped_column(primary_key=True, default=uuid.uuid4)
    user_id: Mapped[int]=mapped_column(ForeignKey('users.id', ondelete='CASCADE'), index=True)
    token_hash: Mapped[str]=mapped_column(String(128), unique=True)
    expires_at: Mapped[datetime]=mapped_column(DateTime(timezone=True))
    revoked_at: Mapped[datetime|None]=mapped_column(DateTime(timezone=True), nullable=True)

class Task(TimestampMixin, Base):
    __tablename__='tasks'
    id: Mapped[int]=mapped_column(primary_key=True)
    title: Mapped[str]=mapped_column(String(160)); description: Mapped[str]=mapped_column(Text)
    image_file_id: Mapped[str|None]=mapped_column(String(255), nullable=True)
    link: Mapped[str|None]=mapped_column(String(1000), nullable=True)
    instructions: Mapped[str]=mapped_column(Text); reward: Mapped[int]=mapped_column(BigInteger)
    evidence_type: Mapped[str]=mapped_column(String(30), default='PHOTO')
    active: Mapped[bool]=mapped_column(Boolean, default=True, index=True)
    start_at: Mapped[datetime|None]=mapped_column(DateTime(timezone=True), nullable=True)
    end_at: Mapped[datetime|None]=mapped_column(DateTime(timezone=True), nullable=True)

class TaskSubmission(TimestampMixin, Base):
    __tablename__='task_submissions'
    id: Mapped[uuid.UUID]=mapped_column(primary_key=True, default=uuid.uuid4)
    user_id: Mapped[int]=mapped_column(ForeignKey('users.id', ondelete='CASCADE'), index=True)
    task_id: Mapped[int]=mapped_column(ForeignKey('tasks.id', ondelete='CASCADE'), index=True)
    telegram_user_id: Mapped[int]=mapped_column(BigInteger)
    evidence_file_id: Mapped[str]=mapped_column(String(255))
    status: Mapped[SubmissionStatus]=mapped_column(SAEnum(SubmissionStatus), default=SubmissionStatus.PENDING, index=True)
    reward: Mapped[int]=mapped_column(BigInteger)
    reviewed_at: Mapped[datetime|None]=mapped_column(DateTime(timezone=True), nullable=True)
    reviewer_admin_id: Mapped[int|None]=mapped_column(BigInteger, nullable=True)
    rejection_reason: Mapped[str|None]=mapped_column(Text, nullable=True)
    __table_args__=(Index('ix_submission_user_task_status','user_id','task_id','status'), Index('uq_submission_pending','user_id','task_id',unique=True,postgresql_where=sa_text("status = 'PENDING'")), Index('uq_submission_approved','user_id','task_id',unique=True,postgresql_where=sa_text("status = 'APPROVED'")))

class Referral(TimestampMixin, Base):
    __tablename__='referrals'
    id: Mapped[uuid.UUID]=mapped_column(primary_key=True, default=uuid.uuid4)
    referrer_user_id: Mapped[int]=mapped_column(ForeignKey('users.id'), index=True)
    referred_user_id: Mapped[int]=mapped_column(ForeignKey('users.id'), unique=True, index=True)
    code: Mapped[str]=mapped_column(String(32), index=True)
    status: Mapped[ReferralStatus]=mapped_column(SAEnum(ReferralStatus), default=ReferralStatus.ATTRIBUTED)
    rewarded_at: Mapped[datetime|None]=mapped_column(DateTime(timezone=True), nullable=True)
    fraud_reason: Mapped[str|None]=mapped_column(Text, nullable=True)

class ReferralReward(Base):
    __tablename__='referral_rewards'
    id: Mapped[uuid.UUID]=mapped_column(primary_key=True, default=uuid.uuid4)
    referral_id: Mapped[uuid.UUID]=mapped_column(ForeignKey('referrals.id', ondelete='CASCADE'), unique=True)
    referrer_coins: Mapped[int]=mapped_column(BigInteger); referred_coins: Mapped[int]=mapped_column(BigInteger)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True), default=utcnow)

class DailyReward(Base):
    __tablename__='daily_rewards'
    id: Mapped[int]=mapped_column(primary_key=True)
    user_id: Mapped[int]=mapped_column(ForeignKey('users.id', ondelete='CASCADE'))
    reward_date: Mapped[date]=mapped_column(Date)
    amount: Mapped[int]=mapped_column(BigInteger)
    claimed_at: Mapped[datetime]=mapped_column(DateTime(timezone=True), default=utcnow)
    __table_args__=(UniqueConstraint('user_id','reward_date',name='uq_daily_user_date'),)

class Withdrawal(TimestampMixin, Base):
    __tablename__='withdrawals'
    id: Mapped[str]=mapped_column(String(32), primary_key=True)
    user_id: Mapped[int]=mapped_column(ForeignKey('users.id'), index=True)
    coins: Mapped[int]=mapped_column(BigInteger); amount_toman: Mapped[Decimal]=mapped_column(Numeric(20,0))
    card_number: Mapped[str]=mapped_column(String(16)); card_holder: Mapped[str]=mapped_column(String(120))
    status: Mapped[WithdrawalStatus]=mapped_column(SAEnum(WithdrawalStatus), default=WithdrawalStatus.PENDING, index=True)
    paid_at: Mapped[datetime|None]=mapped_column(DateTime(timezone=True), nullable=True)
    reviewer_admin_id: Mapped[int|None]=mapped_column(BigInteger, nullable=True)
    rejection_reason: Mapped[str|None]=mapped_column(Text, nullable=True)

class Notification(Base):
    __tablename__='notifications'
    id: Mapped[uuid.UUID]=mapped_column(primary_key=True, default=uuid.uuid4)
    user_id: Mapped[int]=mapped_column(ForeignKey('users.id', ondelete='CASCADE'), index=True)
    type: Mapped[str]=mapped_column(String(40)); text: Mapped[str]=mapped_column(Text); read: Mapped[bool]=mapped_column(Boolean, default=False, index=True)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True), default=utcnow)

class Admin(Base):
    __tablename__='admins'
    id: Mapped[int]=mapped_column(primary_key=True)
    telegram_user_id: Mapped[int]=mapped_column(BigInteger, unique=True)
    role: Mapped[str]=mapped_column(String(30), default='ADMIN')
    active: Mapped[bool]=mapped_column(Boolean, default=True)

class AuditLog(Base):
    __tablename__='audit_logs'
    id: Mapped[uuid.UUID]=mapped_column(primary_key=True, default=uuid.uuid4)
    actor_user_id: Mapped[int|None]=mapped_column(BigInteger, nullable=True)
    actor_admin_id: Mapped[int|None]=mapped_column(BigInteger, nullable=True)
    action: Mapped[str]=mapped_column(String(80), index=True)
    target_type: Mapped[str|None]=mapped_column(String(50), nullable=True)
    target_id: Mapped[str|None]=mapped_column(String(128), nullable=True)
    metadata_json: Mapped[str|None]=mapped_column(Text, nullable=True)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True), default=utcnow)

class Setting(Base):
    __tablename__='settings'
    key: Mapped[str]=mapped_column(String(80), primary_key=True)
    value: Mapped[str]=mapped_column(Text)
    updated_at: Mapped[datetime]=mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)
