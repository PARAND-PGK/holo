import time
from collections import defaultdict, deque
from aiogram import Router
from aiogram.filters import CommandStart
from aiogram.types import Message
from app.db.session import SessionLocal
from app.services.verification import issue_code
from app.services.settings import get_setting
from app.core.config import settings

router = Router()
_rate = defaultdict(deque)


def allowed(user_id: int, limit: int = 3, window: int = 60) -> bool:
    now = time.monotonic()
    q = _rate[user_id]
    while q and now - q[0] >= window:
        q.popleft()
    if len(q) >= limit:
        return False
    q.append(now)
    return True

@router.message(CommandStart())
async def verify_start(m: Message):
    if not allowed(m.from_user.id):
        return await m.answer('⏳ لطفاً کمی صبر کنید و دوباره تلاش کنید.')
    async with SessionLocal() as s:
        ttl = int(await get_setting(s, 'verification_code_expiry', '120'))
        code = await issue_code(s, m.from_user.id, ttl)
        await s.commit()
    await m.answer(
        f'🔐 کد تأیید شما:\n\n<code>{code}</code>\n\n'
        f'این کد را در ربات PODE وارد کنید.\n⏳ اعتبار: {max(1, ttl // 60)} دقیقه',
        parse_mode='HTML'
    )
