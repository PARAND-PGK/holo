import uuid
from datetime import datetime
from decimal import Decimal
from zoneinfo import ZoneInfo
from aiogram import Router, F, Bot
from aiogram.filters import CommandStart
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from sqlalchemy import select, func, or_
from sqlalchemy.exc import IntegrityError
from app.db.session import SessionLocal
from app.models.entities import *
from app.keyboards.main import *
from app.states.user import Registration, Login, TaskFlow, WithdrawalFlow
from app.services.users import create_user, authenticate, validate_password, clean_name
from app.services.verification import verify
from app.services.wallet import credit, lock_withdrawal
from app.services.settings import get_setting
from app.services.referrals import attribute
from app.core.config import settings
router=Router()

def phone_norm(v):
    digits=''.join(c for c in (v or '') if c.isdigit())
    return '+'+digits if digits else ''

async def current_user(m):
    async with SessionLocal() as s: return await s.scalar(select(User).where(User.telegram_user_id==m.from_user.id))

@router.message(CommandStart())
async def start(m:Message,state:FSMContext):
    u=await current_user(m)
    if u: return await m.answer('به PODE خوش آمدید 💰\n\nاز منوی زیر ادامه دهید.',reply_markup=dashboard())
    args=(m.text or '').split(maxsplit=1); ref=args[1].strip() if len(args)>1 else ''
    await state.clear(); await state.update_data(referral_code=ref[:32])
    await m.answer('به PODE خوش آمدید 💰\n\nدر PODE می‌توانید با انجام فعالیت‌های مختلف، دعوت دوستان و دریافت پاداش‌ها سکه کسب کنید.\n\nبرای شروع یکی از گزینه‌های زیر را انتخاب کنید:',reply_markup=auth_kb())

@router.message(F.text=='ثبت نام 👤')
async def reg_start(m,state): await state.clear(); await state.set_state(Registration.name); await m.answer('لطفاً نام خود را وارد کنید:')
@router.message(Registration.name)
async def reg_name(m,state):
    if not clean_name(m.text or ''): return await m.answer('❌ نام باید بین ۲ تا ۸۰ کاراکتر و بدون کاراکترهای کنترلی باشد.')
    await state.update_data(name=m.text.strip()); await state.set_state(Registration.phone); await m.answer('📱 شماره تلفن خود را با دکمه زیر ارسال کنید:',reply_markup=contact_kb())
@router.message(Registration.phone,F.contact)
async def reg_phone(m,state):
    if not m.contact or m.contact.user_id!=m.from_user.id: return await m.answer('❌ فقط شماره متعلق به حساب تلگرام خودتان را ارسال کنید.')
    phone=phone_norm(m.contact.phone_number)
    async with SessionLocal() as s:
        if await s.scalar(select(User).where(or_(User.phone==phone,User.telegram_user_id==m.from_user.id))): return await m.answer('❌ این شماره یا حساب قبلاً ثبت شده است.')
    d=await state.get_data(); await state.update_data(phone=phone); await state.set_state(Registration.verification); await m.answer('برای دریافت کد، Verification Bot را Start کنید:',reply_markup=verification_kb())
@router.message(Registration.verification)
async def reg_code(m,state):
    code=(m.text or '').strip()
    if not (code.isdigit() and len(code)==6): return await m.answer('❌ کد باید ۶ رقمی باشد.')
    async with SessionLocal() as s:
        try:
            ok=await verify(s,m.from_user.id,code,int(await get_setting(s,'max_verification_attempts','5')))
            if not ok:
                await s.rollback(); return await m.answer('❌ کد صحیح نیست، منقضی شده یا تعداد تلاش‌ها تمام شده است.')
            await s.commit()
        except Exception:
            await s.rollback()
            return await m.answer('❌ خطایی در بررسی کد رخ داد. لطفاً یک کد جدید دریافت کنید.')
    await state.set_state(Registration.password); await m.answer('🔐 رمز عبور انتخاب کنید: حداقل ۸ کاراکتر، یک حرف بزرگ، یک حرف کوچک، یک عدد و یک Symbol.')
@router.message(Registration.password)
async def reg_pass(m,state):
    if not validate_password(m.text or ''): return await m.answer('❌ رمز عبور شرایط لازم را ندارد.')
    await state.update_data(password=m.text); await state.set_state(Registration.password_confirm); await m.answer('🔐 رمز عبور را دوباره وارد کنید:')
@router.message(Registration.password_confirm)
async def reg_confirm(m,state):
    d=await state.get_data()
    if m.text!=d.get('password'): return await m.answer('❌ دو رمز عبور یکسان نیستند.')
    async with SessionLocal() as s:
        try:
            u=await create_user(s,m.from_user.id,d['phone'],d['name'],m.text)
            if d.get('referral_code'): await attribute(s,u.id,d['referral_code'])
            await s.commit()
        except (ValueError,IntegrityError): await s.rollback(); return await m.answer('❌ ثبت‌نام انجام نشد. ممکن است حساب یا شماره قبلاً ثبت شده باشد.')
    await state.clear(); await m.answer('🎉 ثبت‌نام شما با موفقیت انجام شد.',reply_markup=dashboard())

@router.message(F.text=='ورود 👤')
async def login_start(m,state): await state.clear(); await state.set_state(Login.phone); await m.answer('📱 شماره تلفن خود را ارسال کنید:',reply_markup=contact_kb())
@router.message(Login.phone,F.contact)
async def login_phone(m,state):
    if not m.contact or m.contact.user_id!=m.from_user.id: return await m.answer('❌ شماره باید متعلق به حساب تلگرام شما باشد.')
    await state.update_data(phone=phone_norm(m.contact.phone_number)); await state.set_state(Login.verification); await m.answer('برای دریافت کد، Verification Bot را Start کنید:',reply_markup=verification_kb())
@router.message(Login.verification)
async def login_code(m,state):
    code=(m.text or '').strip()
    if not (code.isdigit() and len(code)==6): return await m.answer('❌ کد باید ۶ رقمی باشد.')
    async with SessionLocal() as s:
        try:
            if not await verify(s,m.from_user.id,code,int(await get_setting(s,'max_verification_attempts','5'))):
                await s.rollback(); return await m.answer('❌ کد صحیح نیست یا منقضی شده است.')
            await s.commit()
        except Exception:
            await s.rollback()
            return await m.answer('❌ خطایی در بررسی کد رخ داد. لطفاً یک کد جدید دریافت کنید.')
    await state.set_state(Login.password); await m.answer('🔐 رمز عبور را وارد کنید:')
@router.message(Login.password)
async def login_pass(m,state):
    d=await state.get_data()
    async with SessionLocal() as s: u=await authenticate(s,m.from_user.id,d.get('phone',''),m.text or '')
    if not u: return await m.answer('❌ اطلاعات ورود صحیح نیست.')
    await state.clear(); await m.answer('✅ ورود موفق بود.',reply_markup=dashboard())

@router.message(F.text=='💰 تسک ها')
async def tasks(m):
    async with SessionLocal() as s:
        rows=(await s.scalars(select(Task).where(Task.active.is_(True)).order_by(Task.id.desc()))).all()
        if not rows: return await m.answer('فعلاً تسک فعالی وجود ندارد.',reply_markup=dashboard())
        for t in rows:
            text=f'📋 {t.title}\n🪙 پاداش: {t.reward:,} سکه\n\n{t.description}\n\n📝 دستورالعمل:\n{t.instructions}'
            await m.answer_photo(t.image_file_id,caption=text,reply_markup=task_actions(t.id,t.link)) if t.image_file_id else await m.answer(text,reply_markup=task_actions(t.id,t.link))

@router.callback_query(F.data.startswith('task:done:'))
async def task_done(c,state):
    tid=int(c.data.split(':')[2])
    async with SessionLocal() as s:
        u=await s.scalar(select(User).where(User.telegram_user_id==c.from_user.id)); t=await s.get(Task,tid)
        if not u or u.status!=UserStatus.ACTIVE or not t or not t.active: return await c.answer('تسک در دسترس نیست.',show_alert=True)
        approved=await s.scalar(select(TaskSubmission).where(TaskSubmission.user_id==u.id,TaskSubmission.task_id==tid,TaskSubmission.status==SubmissionStatus.APPROVED))
        pending=await s.scalar(select(TaskSubmission).where(TaskSubmission.user_id==u.id,TaskSubmission.task_id==tid,TaskSubmission.status==SubmissionStatus.PENDING))
        if approved: return await c.answer('این تسک قبلاً تأیید شده است.',show_alert=True)
        if pending: return await c.answer('این تسک در انتظار بررسی است.',show_alert=True)
    await state.update_data(task_id=tid); await state.set_state(TaskFlow.evidence); await c.message.answer('📸 لطفاً مدرک انجام تسک را ارسال کنید.'); await c.answer()
@router.message(TaskFlow.evidence,F.photo)
async def evidence(m,state):
    d=await state.get_data(); tid=int(d.get('task_id',0))
    async with SessionLocal() as s:
        u=await s.scalar(select(User).where(User.telegram_user_id==m.from_user.id)); t=await s.get(Task,tid)
        if not u or not t or not t.active: return await m.answer('❌ تسک پیدا نشد.')
        approved=await s.scalar(select(TaskSubmission).where(TaskSubmission.user_id==u.id,TaskSubmission.task_id==tid,TaskSubmission.status==SubmissionStatus.APPROVED))
        pending=await s.scalar(select(TaskSubmission).where(TaskSubmission.user_id==u.id,TaskSubmission.task_id==tid,TaskSubmission.status==SubmissionStatus.PENDING))
        if approved or pending: return await m.answer('این تسک قبلاً ثبت شده است.')
        s.add(TaskSubmission(user_id=u.id,task_id=t.id,telegram_user_id=m.from_user.id,evidence_file_id=m.photo[-1].file_id,reward=t.reward)); await s.commit()
    await state.clear(); await m.answer('✅ مدرک ثبت شد و برای بررسی ارسال شد.',reply_markup=dashboard())

@router.message(F.text=='⭐️ پاداش روزانه')
async def daily(m):
    async with SessionLocal() as s:
        u=await s.scalar(select(User).where(User.telegram_user_id==m.from_user.id)); d=datetime.now(ZoneInfo(settings.timezone)).date(); amount=int(await get_setting(s,'daily_reward','100'))
        try:
            s.add(DailyReward(user_id=u.id,reward_date=d,amount=amount)); await s.flush()
            await credit(s,u.id,amount,TransactionType.DAILY_REWARD,'Daily reward',f'{u.id}:{d}',f'daily:{u.id}:{d}'); await s.commit()
        except IntegrityError: await s.rollback(); return await m.answer('🎁 پاداش امروز را قبلاً دریافت کرده‌اید.',reply_markup=dashboard())
    await m.answer(f'🎁 {amount:,} سکه به کیف پول شما اضافه شد.',reply_markup=dashboard())

@router.message(F.text=='👥 دعوت دوستان')
async def referrals(m):
    async with SessionLocal() as s:
        u=await s.scalar(select(User).where(User.telegram_user_id==m.from_user.id)); count=await s.scalar(select(func.count()).select_from(Referral).where(Referral.referrer_user_id==u.id,Referral.status==ReferralStatus.REWARDED)); income=await s.scalar(select(func.coalesce(func.sum(WalletTransaction.amount),0)).where(WalletTransaction.user_id==u.id,WalletTransaction.type==TransactionType.REFERRAL_REWARD))
    await m.answer(f'👥 دعوت دوستان\n\n🔗 لینک اختصاصی شما:\nhttps://t.me/{settings.main_bot_username}?start={u.referral_code}\n\n👤 دعوت موفق: {count}\n🪙 درآمد از دعوت‌ها: {income or 0:,} سکه',reply_markup=dashboard())

@router.message(F.text=='👛 کیف پول')
async def wallet(m):
    async with SessionLocal() as s:
        u=await s.scalar(select(User).where(User.telegram_user_id==m.from_user.id)); w=await s.get(Wallet,u.id)
    await m.answer(f'👛 کیف پول PODE\n\n🪙 موجودی قابل برداشت: {w.available:,} سکه\n🔒 قفل‌شده: {w.locked:,} سکه\n💵 ارزش قابل برداشت: {(w.available*100):,} تومان',reply_markup=dashboard())

@router.message(F.text=='💳 برداشت')
async def wd_start(m,state): await state.clear(); await state.set_state(WithdrawalFlow.amount); await m.answer('💰 مبلغ موردنظر برای برداشت را به تومان وارد کنید:')
@router.message(WithdrawalFlow.amount)
async def wd_amount(m,state):
    if not (m.text or '').isdigit(): return await m.answer('❌ مبلغ باید عدد صحیح باشد.')
    toman=int(m.text); coin_value=100
    async with SessionLocal() as s:
        coin_value=int(await get_setting(s,'coin_value_toman','100')); minimum=int(await get_setting(s,'minimum_withdrawal_coins','1000')); u=await s.scalar(select(User).where(User.telegram_user_id==m.from_user.id)); w=await s.get(Wallet,u.id)
    if toman<=0 or toman%coin_value: return await m.answer(f'❌ مبلغ باید مضربی از {coin_value:,} تومان باشد.')
    coins=toman//coin_value
    if coins<minimum: return await m.answer(f'❌ حداقل برداشت {minimum:,} سکه است.')
    if not w or w.available<coins: return await m.answer('❌ موجودی شما برای برداشت کافی نیست.')
    await state.update_data(coins=coins,toman=toman); await state.set_state(WithdrawalFlow.card); await m.answer('💳 شماره کارت ۱۶ رقمی را وارد کنید:')
@router.message(WithdrawalFlow.card)
async def wd_card(m,state):
    card=''.join(c for c in (m.text or '') if c.isdigit())
    if len(card)!=16: return await m.answer('❌ شماره کارت باید ۱۶ رقم باشد.')
    await state.update_data(card=card); await state.set_state(WithdrawalFlow.holder); await m.answer('👤 نام صاحب کارت را وارد کنید:')
@router.message(WithdrawalFlow.holder)
async def wd_holder(m,state):
    if not clean_name(m.text or ''): return await m.answer('❌ نام نامعتبر است.')
    d=await state.get_data(); await state.update_data(holder=m.text.strip()); await state.set_state(WithdrawalFlow.confirm); await m.answer(f'💳 درخواست برداشت\n\n🪙 {d["coins"]:,} سکه\n💵 {d["toman"]:,} تومان\n💳 **** **** **** {d["card"][-4:]}\n👤 {m.text.strip()}\n\nدرخواست را تأیید می‌کنید؟',reply_markup=confirm_withdrawal())
@router.callback_query(WithdrawalFlow.confirm,F.data=='wd:confirm')
async def wd_confirm(c,state):
    d=await state.get_data(); wid='WD-'+uuid.uuid4().hex[:12].upper()
    async with SessionLocal() as s:
        u=await s.scalar(select(User).where(User.telegram_user_id==c.from_user.id))
        pending=await s.scalar(select(Withdrawal).where(Withdrawal.user_id==u.id,Withdrawal.status==WithdrawalStatus.PENDING))
        if pending: return await c.answer('شما یک برداشت در انتظار بررسی دارید.',show_alert=True)
        try: await lock_withdrawal(s,u.id,int(d['coins']),wid); s.add(Withdrawal(id=wid,user_id=u.id,coins=int(d['coins']),amount_toman=Decimal(d['toman']),card_number=d['card'],card_holder=d['holder'])); s.add(Notification(user_id=u.id,type='WITHDRAWAL_CREATED',text=f'درخواست برداشت {wid} ثبت شد.')); await s.commit()
        except (ValueError,IntegrityError): await s.rollback(); return await c.answer('ثبت برداشت انجام نشد؛ موجودی یا وضعیت درخواست را بررسی کنید.',show_alert=True)
    await state.clear(); await c.message.answer(f'✅ درخواست برداشت ثبت شد.\n🆔 {wid}\n⏳ در انتظار بررسی',reply_markup=dashboard()); await c.answer()
@router.callback_query(F.data=='wd:cancel')
async def wd_cancel(c,state): await state.clear(); await c.message.answer('❌ درخواست لغو شد.',reply_markup=dashboard()); await c.answer()

@router.message(F.text=='🔔 اعلان‌ها')
async def notifications(m):
    async with SessionLocal() as s:
        u=await s.scalar(select(User).where(User.telegram_user_id==m.from_user.id)); rows=(await s.scalars(select(Notification).where(Notification.user_id==u.id).order_by(Notification.created_at.desc()).limit(15))).all()
        for n in rows: n.read=True
        await s.commit()
    text='🔔 اعلان‌ها\n\n'+('\n\n'.join('• '+n.text for n in rows) if rows else 'اعلانی ندارید.')
    await m.answer(text,reply_markup=dashboard())
