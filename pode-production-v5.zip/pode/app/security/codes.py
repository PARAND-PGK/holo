import hashlib, hmac, secrets
from app.core.config import settings
def make_code()->str: return f'{secrets.randbelow(1_000_000):06d}'
def hash_code(code:str)->str: return hmac.new(settings.secret_key.encode(),code.encode(),hashlib.sha256).hexdigest()
def verify_code(code:str,digest:str)->bool: return hmac.compare_digest(hash_code(code),digest)
def random_token()->str: return secrets.token_urlsafe(32)
def hash_token(token:str)->str: return hashlib.sha256(token.encode()).hexdigest()
