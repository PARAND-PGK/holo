from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from app.core.config import settings
ph=PasswordHasher()
def hash_password(password:str)->str: return ph.hash(password+settings.password_pepper)
def verify_password(stored:str,password:str)->bool:
    try: return ph.verify(stored,password+settings.password_pepper)
    except VerifyMismatchError: return False
