from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from app.core.config import settings

def auth_kb(): return ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text='ثبت نام 👤'),KeyboardButton(text='ورود 👤')]],resize_keyboard=True)
def dashboard(): return ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text='💰 تسک ها')],[KeyboardButton(text='⭐️ پاداش روزانه'),KeyboardButton(text='👥 دعوت دوستان')],[KeyboardButton(text='👛 کیف پول'),KeyboardButton(text='💳 برداشت')],[KeyboardButton(text='🔔 اعلان‌ها')]],resize_keyboard=True)
def contact_kb(): return ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text='📱 اشتراک شماره تلفن',request_contact=True)]],resize_keyboard=True,one_time_keyboard=True)
def verification_kb(): return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text='📩 دریافت کد تأیید',url=f'https://t.me/{settings.verification_bot_username}?start=verify')]])
def task_actions(task_id,link=None):
    rows=[]
    if link: rows.append([InlineKeyboardButton(text='🔗 مشاهده تسک',url=link)])
    rows.append([InlineKeyboardButton(text='✅ انجام دادم',callback_data=f'task:done:{task_id}'),InlineKeyboardButton(text='❌ لغو',callback_data='task:cancel')])
    return InlineKeyboardMarkup(inline_keyboard=rows)
def confirm_withdrawal(): return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text='✅ تأیید درخواست',callback_data='wd:confirm'),InlineKeyboardButton(text='❌ لغو',callback_data='wd:cancel')]])
