import json, os
from datetime import datetime, timezone
from fastapi import FastAPI, Header, HTTPException, Depends
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from sqlalchemy import text, select, func, or_
from aiogram import Bot
from app.db.session import SessionLocal, engine
from app.core.config import settings
from app.models.entities import *
from app.services.wallet import credit, debit, refund_withdrawal, complete_withdrawal
from app.services.notifications import notify
from app.services.settings import get_setting, set_setting

app=FastAPI(title='PODE Admin API',version='2.0.0')

class TaskIn(BaseModel):
    title:str=Field(min_length=2,max_length=160); description:str=''; instructions:str=''; reward:int=Field(gt=0); link:str|None=None; image_file_id:str|None=None; evidence_type:str='PHOTO'; active:bool=True
class SettingIn(BaseModel): value:str
class CoinIn(BaseModel): amount:int=Field(ne=0); reason:str=Field(min_length=2,max_length=255)

def admin_id(x:str):
    try: return int(x)
    except: raise HTTPException(401,'unauthorized')
async def guard(x_admin_id:str=Header(default=''), x_admin_secret:str=Header(default='')):
    aid=admin_id(x_admin_id)
    if aid not in settings.admin_id_set() or not settings.admin_api_secret or x_admin_secret!=settings.admin_api_secret: raise HTTPException(403,'forbidden')
    async with SessionLocal() as s:
        a=await s.scalar(select(Admin).where(Admin.telegram_user_id==aid,Admin.active.is_(True)))
        if a is None: raise HTTPException(403,'admin not provisioned')
        return aid,a.role

@app.get('/health')
async def health():
    async with engine.connect() as c: await c.execute(text('SELECT 1'))
    return {'status':'ok'}

@app.get('/admin',response_class=HTMLResponse)
async def admin_page():
    return HTMLResponse(r'''<!doctype html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>PODE Admin Panel</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f3f5f8;color:#17202a;font-family:Tahoma,Arial,sans-serif}.wrap{max-width:1400px;margin:auto;padding:18px}.top{background:#111827;color:white;border-radius:18px;padding:20px;margin-bottom:14px}.top h1{margin:0 0 6px}.top small{opacity:.75}.login,.card{background:white;border-radius:16px;padding:16px;margin:12px 0;box-shadow:0 4px 20px #0000000d}.login{display:grid;grid-template-columns:1fr 1fr auto;gap:8px}.nav{display:flex;gap:8px;flex-wrap:wrap;margin:12px 0}.nav button{border:0;border-radius:10px;padding:10px 14px;cursor:pointer;background:#e5e7eb}.nav button.active{background:#111827;color:#fff}.page{display:none}.page.active{display:block}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px}.stat{background:#fff;border-radius:14px;padding:16px}.stat b{font-size:25px;display:block;margin-top:5px}button,input,textarea,select{font:inherit}button.primary{background:#111827;color:#fff;border:0;border-radius:9px;padding:9px 13px;cursor:pointer}button.ok{background:#dcfce7;border:0;padding:7px 10px;border-radius:8px;cursor:pointer}button.no{background:#fee2e2;border:0;padding:7px 10px;border-radius:8px;cursor:pointer}.row{border-bottom:1px solid #eee;padding:12px 0}.muted{color:#667085;font-size:13px}pre{white-space:pre-wrap;overflow:auto;background:#f8fafc;padding:10px;border-radius:10px}table{width:100%;border-collapse:collapse;background:white}th,td{text-align:right;padding:10px;border-bottom:1px solid #eee}form{display:grid;gap:8px}input,textarea,select{padding:10px;border:1px solid #d7dce2;border-radius:9px;width:100%}.two{display:grid;grid-template-columns:1fr 1fr;gap:8px}@media(max-width:700px){.login,.two{grid-template-columns:1fr}}
</style></head><body><div class="wrap">
<div class="top"><h1>👑 PODE Admin Panel V5</h1><small>مدیریت کاربران، تسک‌ها، درخواست‌ها، برداشت‌ها و تنظیمات</small></div>
<div class="login"><input id="aid" placeholder="Telegram Admin ID"><input id="secret" placeholder="ADMIN_API_SECRET" type="password"><button class="primary" onclick="login()">🔐 ورود</button></div>
<div id="status" class="muted"></div>
<div class="nav"><button data-p="dashboard" class="active" onclick="show('dashboard',this)">📊 داشبورد</button><button data-p="subs" onclick="show('subs',this)">⏳ تسک‌ها</button><button data-p="withdrawals" onclick="show('withdrawals',this)">💸 برداشت‌ها</button><button data-p="users" onclick="show('users',this)">👥 کاربران</button><button data-p="tasks" onclick="show('tasks',this)">📝 ساخت تسک</button><button data-p="settings" onclick="show('settings',this)">⚙️ تنظیمات</button></div>
<section id="dashboard" class="page active"><div class="grid"><div class="stat">👥 کاربران<b id="u">-</b></div><div class="stat">📝 تسک‌ها<b id="t">-</b></div><div class="stat">⏳ در انتظار بررسی<b id="ps">-</b></div><div class="stat">💸 برداشت در انتظار<b id="pw">-</b></div><div class="stat">🪙 مجموع سکه مثبت<b id="pc">-</b></div><div class="stat">💰 پرداخت‌شده (تومان)<b id="pt">-</b></div></div></section>
<section id="subs" class="page card"><h2>⏳ ارسال‌های در انتظار</h2><div id="subsList">برای ورود، اطلاعات ادمین را وارد کنید.</div></section>
<section id="withdrawals" class="page card"><h2>💸 برداشت‌های در انتظار</h2><div id="wdList">-</div></section>
<section id="users" class="page card"><h2>👥 کاربران</h2><div class="two"><input id="userQ" placeholder="نام، شماره یا Telegram ID"><button class="primary" onclick="loadUsers()">🔎 جستجو</button></div><div id="userList">-</div></section>
<section id="tasks" class="page card"><h2>📝 ساخت تسک</h2><form onsubmit="createTask(event)"><input id="tt" placeholder="عنوان تسک" required><textarea id="td" placeholder="توضیحات"></textarea><textarea id="ti" placeholder="دستورالعمل"></textarea><div class="two"><input id="tr" type="number" min="1" placeholder="پاداش سکه" required><input id="tl" placeholder="لینک (اختیاری)"></div><select id="te"><option value="PHOTO">PHOTO</option><option value="TEXT">TEXT</option><option value="VIDEO">VIDEO</option></select><button class="primary">➕ ساخت تسک</button></form><div id="taskMsg"></div></section>
<section id="settings" class="page card"><h2>⚙️ تنظیمات</h2><div id="settingsList">-</div></section>
</div><script>
const $=id=>document.getElementById(id); let logged=false;
const H=()=>({'X-Admin-ID':$('aid').value.trim(),'X-Admin-Secret':$('secret').value});
async function api(url,opt={}){const headers={'Content-Type':'application/json',...H(),...(opt.headers||{})};const r=await fetch(url,{...opt,headers});const txt=await r.text();let d;try{d=JSON.parse(txt)}catch{d=txt}if(!r.ok)throw new Error(typeof d==='string'?d:(d.detail||JSON.stringify(d)));return d}
function show(id,btn){document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));$(id).classList.add('active');document.querySelectorAll('.nav button').forEach(x=>x.classList.remove('active'));if(btn)btn.classList.add('active');if(logged){if(id==='dashboard')loadStats();if(id==='subs')loadSubs();if(id==='withdrawals')loadWds();if(id==='users')loadUsers();if(id==='settings')loadSettings()}}
async function login(){try{await api('/admin/stats');logged=true;$('status').textContent='✅ ورود موفق بود';await loadStats();await loadSubs();await loadWds();await loadUsers();await loadSettings()}catch(e){$('status').textContent='❌ '+e.message}}
async function loadStats(){let x=await api('/admin/stats');$('u').textContent=x.users.toLocaleString();$('t').textContent=x.tasks.toLocaleString();$('ps').textContent=x.pending_submissions.toLocaleString();$('pw').textContent=x.pending_withdrawals.toLocaleString();$('pc').textContent=x.total_positive_coin_ledger.toLocaleString();$('pt').textContent=x.total_paid_toman.toLocaleString()}
async function loadSubs(){let a=await api('/admin/submissions');$('subsList').innerHTML=a.length?a.map(x=>`<div class="row"><b>${x.task_title}</b><div class="muted">کاربر: ${x.user_id} | پاداش: ${x.reward.toLocaleString()} | ${x.created_at}</div><button class="ok" onclick="act('/admin/submissions/${x.id}/approve');">✅ تأیید</button> <button class="no" onclick="act('/admin/submissions/${x.id}/reject');">❌ رد</button></div>`).join(''):'موردی وجود ندارد.'}
async function loadWds(){let a=await api('/admin/withdrawals');$('wdList').innerHTML=a.length?a.map(x=>`<div class="row"><b>${x.amount_toman.toLocaleString()} تومان</b><div class="muted">ID: ${x.id} | کاربر: ${x.user_id} | ${x.card} | ${x.card_holder}</div><button class="ok" onclick="act('/admin/withdrawals/${x.id}/pay');">💰 پرداخت</button> <button class="no" onclick="act('/admin/withdrawals/${x.id}/reject');">❌ رد و برگشت</button></div>`).join(''):'موردی وجود ندارد.'}
async function act(u){try{await api(u,{method:'POST'});await loadStats();await loadSubs();await loadWds()}catch(e){alert(e.message)}}
async function loadUsers(){try{let a=await api('/admin/users?q='+encodeURIComponent($('userQ').value));$('userList').innerHTML=a.length?'<table><tr><th>ID</th><th>نام</th><th>Telegram ID</th><th>شماره</th><th>وضعیت</th></tr>'+a.map(x=>`<tr><td>${x.id}</td><td>${x.name}</td><td>${x.telegram_user_id}</td><td>${x.phone}</td><td>${x.status}</td></tr>`).join('')+'</table>':'کاربری پیدا نشد.'}catch(e){$('userList').textContent='❌ '+e.message}}
async function createTask(e){e.preventDefault();try{let d=await api('/admin/tasks',{method:'POST',body:JSON.stringify({title:$('tt').value,description:$('td').value,instructions:$('ti').value,reward:Number($('tr').value),link:$('tl').value||null,evidence_type:$('te').value,active:true})});$('taskMsg').textContent='✅ تسک ساخته شد: '+d.id;e.target.reset();await loadStats()}catch(e){$('taskMsg').textContent='❌ '+e.message}}
async function loadSettings(){try{let a=await api('/admin/settings');let keys=Object.keys(a);$('settingsList').innerHTML=keys.length?keys.map(k=>`<div class="row"><b>${k}</b><input id="set_${encodeURIComponent(k)}" value="${String(a[k]).replaceAll('&','&amp;').replaceAll('"','&quot;')}"><button class="primary" onclick="saveSetting(${JSON.stringify(k)})">ذخیره</button></div>`).join(''):'تنظیمی ثبت نشده است.'}catch(e){$('settingsList').textContent='❌ '+e.message}}
async function saveSetting(k){try{let v=$('set_'+encodeURIComponent(k)).value;await api('/admin/settings/'+encodeURIComponent(k),{method:'PUT',body:JSON.stringify({value:v})});alert('✅ ذخیره شد')}catch(e){alert('❌ '+e.message)}}
</script></body></html>''')

@app.get('/admin/stats')
async def stats(_=Depends(guard)):
    async with SessionLocal() as s:
        q=lambda model: s.scalar(select(func.count()).select_from(model))
        users=await q(User); tasks=await q(Task); pending_sub=await s.scalar(select(func.count()).select_from(TaskSubmission).where(TaskSubmission.status==SubmissionStatus.PENDING)); pending_wd=await s.scalar(select(func.count()).select_from(Withdrawal).where(Withdrawal.status==WithdrawalStatus.PENDING))
        distributed=await s.scalar(select(func.coalesce(func.sum(WalletTransaction.amount),0)).where(WalletTransaction.amount>0))
        paid=await s.scalar(select(func.coalesce(func.sum(Withdrawal.amount_toman),0)).where(Withdrawal.status==WithdrawalStatus.PAID))
    return {'users':users,'tasks':tasks,'pending_submissions':pending_sub,'pending_withdrawals':pending_wd,'total_positive_coin_ledger':int(distributed or 0),'total_paid_toman':int(paid or 0)}

@app.get('/admin/submissions')
async def submissions(_=Depends(guard)):
    async with SessionLocal() as s:
        rows=(await s.execute(select(TaskSubmission,Task.title).join(Task,Task.id==TaskSubmission.task_id).where(TaskSubmission.status==SubmissionStatus.PENDING).order_by(TaskSubmission.created_at))).all()
        return [{'id':str(x.id),'user_id':x.user_id,'task_title':title,'reward':x.reward,'evidence_file_id':x.evidence_file_id,'created_at':x.created_at.isoformat()} for x,title in rows]

async def send_user(tg_id:int,text_msg:str):
    if not settings.main_bot_token:return
    bot=Bot(settings.main_bot_token)
    try: await bot.send_message(tg_id,text_msg)
    finally: await bot.session.close()

@app.post('/admin/submissions/{sid}/approve')
async def approve_submission(sid:str,auth=Depends(guard)):
    aid,role=auth
    if role not in {'ADMIN','MODERATOR','SUPER_ADMIN'}: raise HTTPException(403,'role')
    async with SessionLocal() as s:
        sub=await s.scalar(select(TaskSubmission).where(TaskSubmission.id==sid).with_for_update())
        if not sub: raise HTTPException(404,'not found')
        if sub.status!=SubmissionStatus.PENDING:return {'status':sub.status.value}
        sub.status=SubmissionStatus.APPROVED; sub.reviewed_at=datetime.now(timezone.utc); sub.reviewer_admin_id=aid
        await credit(s,sub.user_id,sub.reward,TransactionType.TASK_REWARD,'Task approved',sid,f'task-reward:{sid}',aid)
        from app.services.referrals import reward_if_qualified
        await reward_if_qualified(s,sub.user_id)
        u=await s.get(User,sub.user_id); await notify(s,sub.user_id,'TASK_APPROVED',f'✅ تسک شما تأیید شد و {sub.reward:,} سکه دریافت کردید.')
        s.add(AuditLog(actor_admin_id=aid,action='TASK_APPROVED',target_type='submission',target_id=sid)); await s.commit()
    try: await send_user(u.telegram_user_id,f'✅ تسک شما تأیید شد.\n🪙 {sub.reward:,} سکه به کیف پول اضافه شد.')
    except Exception: pass
    return {'status':'APPROVED'}

@app.post('/admin/submissions/{sid}/reject')
async def reject_submission(sid:str,auth=Depends(guard)):
    aid,role=auth
    if role not in {'ADMIN','MODERATOR','SUPER_ADMIN'}: raise HTTPException(403,'role')
    async with SessionLocal() as s:
        sub=await s.scalar(select(TaskSubmission).where(TaskSubmission.id==sid).with_for_update())
        if not sub: raise HTTPException(404,'not found')
        if sub.status!=SubmissionStatus.PENDING:return {'status':sub.status.value}
        sub.status=SubmissionStatus.REJECTED; sub.reviewed_at=datetime.now(timezone.utc); sub.reviewer_admin_id=aid
        u=await s.get(User,sub.user_id); await notify(s,sub.user_id,'TASK_REJECTED','❌ مدرک تسک شما رد شد. می‌توانید دوباره تلاش کنید.')
        s.add(AuditLog(actor_admin_id=aid,action='TASK_REJECTED',target_type='submission',target_id=sid)); await s.commit()
    try: await send_user(u.telegram_user_id,'❌ مدرک تسک شما رد شد. می‌توانید دوباره تلاش کنید.')
    except Exception: pass
    return {'status':'REJECTED'}

@app.get('/admin/withdrawals')
async def withdrawals(_=Depends(guard)):
    async with SessionLocal() as s:
        rows=(await s.scalars(select(Withdrawal).where(Withdrawal.status==WithdrawalStatus.PENDING).order_by(Withdrawal.created_at))).all()
        return [{'id':x.id,'user_id':x.user_id,'coins':x.coins,'amount_toman':int(x.amount_toman),'card':'**** **** **** '+x.card_number[-4:],'card_holder':x.card_holder,'status':x.status.value,'created_at':x.created_at.isoformat()} for x in rows]

@app.post('/admin/withdrawals/{wid}/pay')
async def pay_withdrawal(wid:str,auth=Depends(guard)):
    aid,role=auth
    if role not in {'FINANCE','SUPER_ADMIN'}: raise HTTPException(403,'role')
    async with SessionLocal() as s:
        w=await s.scalar(select(Withdrawal).where(Withdrawal.id==wid).with_for_update())
        if not w: raise HTTPException(404,'not found')
        if w.status!=WithdrawalStatus.PENDING:return {'status':w.status.value}
        await complete_withdrawal(s,w.user_id,w.coins,w.id); w.status=WithdrawalStatus.PAID; w.paid_at=datetime.now(timezone.utc); w.reviewer_admin_id=aid
        await notify(s,w.user_id,'WITHDRAWAL_PAID',f'✅ برداشت {wid} پرداخت شد.'); u=await s.get(User,w.user_id)
        s.add(AuditLog(actor_admin_id=aid,action='WITHDRAWAL_PAID',target_type='withdrawal',target_id=wid)); await s.commit()
    try: await send_user(u.telegram_user_id,f'✅ درخواست برداشت {wid} پرداخت شد.')
    except Exception: pass
    return {'status':'PAID'}

@app.post('/admin/withdrawals/{wid}/reject')
async def reject_withdrawal(wid:str,auth=Depends(guard)):
    aid,role=auth
    if role not in {'FINANCE','SUPER_ADMIN'}: raise HTTPException(403,'role')
    async with SessionLocal() as s:
        w=await s.scalar(select(Withdrawal).where(Withdrawal.id==wid).with_for_update())
        if not w: raise HTTPException(404,'not found')
        if w.status!=WithdrawalStatus.PENDING:return {'status':w.status.value}
        await refund_withdrawal(s,w.user_id,w.coins,w.id); w.status=WithdrawalStatus.REFUNDED; w.reviewer_admin_id=aid
        await notify(s,w.user_id,'WITHDRAWAL_REFUNDED',f'❌ برداشت {wid} رد شد و {w.coins:,} سکه به موجودی برگشت.'); u=await s.get(User,w.user_id)
        s.add(AuditLog(actor_admin_id=aid,action='WITHDRAWAL_REJECTED',target_type='withdrawal',target_id=wid)); await s.commit()
    try: await send_user(u.telegram_user_id,f'❌ درخواست برداشت {wid} رد شد و موجودی شما برگشت داده شد.')
    except Exception: pass
    return {'status':'REFUNDED'}

@app.post('/admin/tasks')
async def create_task(data:TaskIn,auth=Depends(guard)):
    aid,role=auth
    if role not in {'ADMIN','SUPER_ADMIN'}: raise HTTPException(403,'role')
    async with SessionLocal() as s:
        t=Task(**data.model_dump()); s.add(t); s.add(AuditLog(actor_admin_id=aid,action='TASK_CREATED',target_type='task',target_id='pending')); await s.commit(); await s.refresh(t); return {'id':t.id}
@app.patch('/admin/tasks/{tid}')
async def update_task(tid:int,data:TaskIn,auth=Depends(guard)):
    aid,role=auth
    if role not in {'ADMIN','SUPER_ADMIN'}: raise HTTPException(403,'role')
    async with SessionLocal() as s:
        t=await s.get(Task,tid)
        if not t: raise HTTPException(404,'not found')
        for k,v in data.model_dump().items(): setattr(t,k,v)
        s.add(AuditLog(actor_admin_id=aid,action='TASK_UPDATED',target_type='task',target_id=str(tid))); await s.commit(); return {'status':'ok'}
@app.delete('/admin/tasks/{tid}')
async def delete_task(tid:int,auth=Depends(guard)):
    aid,role=auth
    if role not in {'ADMIN','SUPER_ADMIN'}: raise HTTPException(403,'role')
    async with SessionLocal() as s:
        t=await s.get(Task,tid)
        if not t: raise HTTPException(404,'not found')
        t.active=False; s.add(AuditLog(actor_admin_id=aid,action='TASK_DISABLED',target_type='task',target_id=str(tid))); await s.commit(); return {'status':'disabled'}

@app.get('/admin/settings')
async def list_settings(auth=Depends(guard)):
    async with SessionLocal() as s:
        rows=(await s.scalars(select(Setting).order_by(Setting.key))).all(); return {r.key:r.value for r in rows}
@app.put('/admin/settings/{key}')
async def update_setting(key:str,data:SettingIn,auth=Depends(guard)):
    aid,role=auth
    if role!='SUPER_ADMIN': raise HTTPException(403,'role')
    async with SessionLocal() as s:
        await set_setting(s,key,data.value); s.add(AuditLog(actor_admin_id=aid,action='SETTING_CHANGED',target_type='setting',target_id=key)); await s.commit(); return {'status':'ok'}

@app.get('/admin/users')
async def users(q:str='',auth=Depends(guard)):
    async with SessionLocal() as s:
        stmt=select(User).order_by(User.id.desc()).limit(100)
        if q: stmt=stmt.where(or_(User.phone.contains(q),User.name.contains(q),User.telegram_user_id==int(q) if q.isdigit() else False))
        rows=(await s.scalars(stmt)).all(); return [{'id':u.id,'telegram_user_id':u.telegram_user_id,'phone':u.phone,'name':u.name,'status':u.status.value} for u in rows]

@app.post('/admin/users/{uid}/coins')
async def admin_coins(uid:int,data:CoinIn,auth=Depends(guard)):
    aid,role=auth
    if role not in {'ADMIN','FINANCE','SUPER_ADMIN'}: raise HTTPException(403,'role')
    async with SessionLocal() as s:
        u=await s.get(User,uid)
        if not u: raise HTTPException(404,'not found')
        typ=TransactionType.ADMIN_CREDIT if data.amount>0 else TransactionType.ADMIN_DEBIT
        fn=credit if data.amount>0 else debit
        await fn(s,uid,abs(data.amount),typ,data.reason,str(uid),f'admin-coin:{aid}:{uid}:{datetime.now(timezone.utc).timestamp()}',aid)
        s.add(AuditLog(actor_admin_id=aid,action='COIN_CHANGE',target_type='user',target_id=str(uid),metadata_json=json.dumps({'amount':data.amount,'reason':data.reason}))); await s.commit(); return {'status':'ok'}
