import asyncio

from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
from fastapi import FastAPI
from sqlalchemy import select
from uvicorn import Config, Server

from app.api.app import app as admin_app
from app.core.config import settings
from app.db.session import SessionLocal, engine
from app.models.base import Base
from app.models import entities  # noqa: F401
from app.models.entities import Admin
from app.bots.main_bot.handlers import router as main_router
from app.bots.verification_bot.handlers import router as verify_router

async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    # Automatically provision IDs listed in ADMIN_IDS as SUPER_ADMINs.
    ids = settings.admin_id_set()
    if ids:
        async with SessionLocal() as s:
            for tg_id in ids:
                row = await s.scalar(select(Admin).where(Admin.telegram_user_id == tg_id))
                if row is None:
                    s.add(Admin(telegram_user_id=tg_id, role='SUPER_ADMIN', active=True))
            await s.commit()

async def run_web():
    config = Config(admin_app, host=settings.admin_host, port=settings.admin_port, log_level='info')
    server = Server(config)
    await server.serve()

async def run():
    if not settings.main_bot_token or not settings.verification_bot_token:
        raise RuntimeError('MAIN_BOT_TOKEN و VERIFICATION_BOT_TOKEN را در فایل .env تنظیم کنید.')
    if not settings.admin_ids:
        raise RuntimeError('ADMIN_IDS را در فایل .env تنظیم کنید.')
    if not settings.admin_api_secret:
        raise RuntimeError('ADMIN_API_SECRET را در فایل .env تنظیم کنید.')

    await init_db()

    # Separate FSM storage prevents the two bots from sharing registration state.
    main_dp = Dispatcher(storage=MemoryStorage())
    verify_dp = Dispatcher(storage=MemoryStorage())
    main_dp.include_router(main_router)
    verify_dp.include_router(verify_router)

    print('\n========================================')
    print(' PODE V5 started')
    print(f' Admin Panel: http://127.0.0.1:{settings.admin_port}/admin')
    print(f' Health:      http://127.0.0.1:{settings.admin_port}/health')
    print('========================================\n')

    async with Bot(settings.main_bot_token) as main, Bot(settings.verification_bot_token) as verify:
        await asyncio.gather(
            main_dp.start_polling(main),
            verify_dp.start_polling(verify),
            run_web(),
        )

if __name__ == '__main__':
    asyncio.run(run())
